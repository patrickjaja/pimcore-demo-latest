<?php
declare(strict_types=1);

namespace Platformsh\ConfigReader;

class NotValidPlatformException extends \RuntimeException
{
}
