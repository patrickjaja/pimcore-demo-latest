<?php
declare(strict_types=1);

namespace Platformsh\ConfigReader;

class NoCredentialFormatterFoundException extends \InvalidArgumentException
{
}
