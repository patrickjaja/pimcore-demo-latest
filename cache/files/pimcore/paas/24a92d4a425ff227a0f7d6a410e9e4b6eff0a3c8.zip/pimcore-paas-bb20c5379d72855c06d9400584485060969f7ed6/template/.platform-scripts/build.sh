#!/bin/bash

# Install composer dependencies
./.platform-scripts/build/composer.sh
