---
title: Pimcore PaaS
---

# Pimcore PaaS

## What is Pimcore PaaS and how does it work?

Pimcore Platform-as-a-Service is a cloud platform for building, running and scaling your Pimcore applications,
provided by the top-notch [Platform.sh technology stack](https://docs.platform.sh/).
It also includes the license for [Pimcore Enterprise Edition](https://pimcore.com/en/platform/enterprise-edition) and
therefore opens up all the possibilities of the extensive features and services.

For a more detailed overview of features, pricing and ordering, please [visit our product page](https://pimcore.com/en/platform/paas).

## Getting Started

First of all it's important to make yourself familiar with the concept of [Platform.sh](https://docs.platform.sh/get-started/introduction.html).
Since there are no major differences between Pimcore PaaS and Platform.sh, there's only the following short on-top documentation
to the [Platform.sh docs](https://docs.platform.sh/), which outlines the specifics of how to run Pimcore on Platform.sh.

## Preparation Work

❗  You need a Pimcore license token and your custom Composer repository URL, both you can find on the license certificate.

❗  If you're starting a new project, just follow the general setup instructions for our [skeleton](https://github.com/pimcore/skeleton?tab=readme-ov-file#docker) or [demo projects](https://github.com/pimcore/demo?tab=readme-ov-file#docker) to setup a local instance of your project. 

❗  If you are migrating from already existing project check out our [migration guide](./doc/03_Migration/README.md)

Once you have your project up and running locally or if you're having an existing project,
you can continue with the following steps to setup PaaS.

## Project Setup

Run the following commands to enable the Pimcore Commercial License and install the Pimcore PaaS tools package to your project.
Don't forget to replace `YOUR_PIMCORE_TOKEN` and `YOUR_REPO_NAME` with the actual values.

```bash
composer config --auth http-basic.repo.pimcore.com token YOUR_PIMCORE_TOKEN
composer config repositories.pimcore_enterprise composer https://repo.pimcore.com/YOUR_REPO_NAME/
composer require pimcore/paas
```

Now enable the Enterprise Subscription Tools bundle in your `/config/bundles.php`, by adding this line:

```php
    \Pimcore\Bundle\EnterpriseSubscriptionToolsBundle\PimcoreEnterpriseSubscriptionToolsBundle::class => ['all' => true],
```

It's now time to install the PaaS specific configuration files to your project, by running

```bash
./vendor/bin/pimcore-paas-install-config
```

The last command will install a bunch of configuration files into your project's directory:

-   `.platform/*` PaaS infrastructure configuration
-   `.platform-scripts/*` deploy and build scripts
-   `config/pimcore/startup.php` dynamic service configuration mapping
-   `config/platform.yaml` Pimcore generic PaaS configuration
-   `.env.(dev|prod)` example config for your different environments

Please commit all of those files to your Git repository.
All of this configurations can be freely customized.

## Project Setup in Console

Please log in to the [console](https://console.pimcore.cloud/).

1. Create a new project in the Console
2. Go to Settings -> Variables and create the following new variables:
    - `env:PIMCORE_TOKEN` with the license token as the value (e.g. `a67ca3fa22e809a1781e15678013bb8...`)
    - `env:PIMCORE_INSTALL_ADMIN_USERNAME` with username for your admin account (e.g. `administrator`) (tick sensitive option)
    - `env:PIMCORE_INSTALL_ADMIN_PASSWORD` with the password for your admin account (tick sensitive option)
3. Follow the setup instructions in the user interface. If the instructions are not already shown by default, please press the "Finish setup".

You should now have a running Pimcore instance on PaaS.

## Next Steps & further Information

- [Customizing your configuration](./doc/01_Configuration/README.md)
- [Some useful tips](./doc/02_Good_to_know/README.md)        
- [Migrating guide from on-premise to PaaS](./doc/03_Migration/README.md)
- [FAQ](./doc/04_Faq/README.md)  
