# Good to know

## Sync existing data

If you are starting your project from public/enterprise demo or an existing project not running on PaaS, you need [syncing data](https://docs.platform.sh/development/transfer-dedicated.html#synchronize-files-from-development-to-stagingproduction)
from local directories `/var/` and `/public/var`.
Afterwards, ensure you are rebuilding your classes:

```bash
./bin/console pimcore:deployment:classes-rebuild --create-classes
```

## Logs

By default configuration, logs are streamed to `stderr`
Platform.sh stores those logs within `/var/log/` directory.
You can find more details about how to access them [here](https://docs.platform.sh/increase-observability/logs/access-logs.html#container-logs).

## Running commands
You should run your commands using prod env variable `--env=prod`, especially when you are using interactive shell.
```bash
bin/console pimcore:bundle:list --json --no-debug --env=prod
``` 
## Symfony cache dir

By default configuration, Symfony cache dir is set to `/app/localCache`.
If you would like to change that consider changing the corresponding mount in the `applications.yaml`.

## Working with definition files

The way of working with class definitions is not specific to PaaS, it's a general thing to consider depending on the way how you want to work with class definitions no matter where you run your Pimcore instance.

While in some cases it is useful to have class definitions stored in Git under `/var`, we do not recommend that. 
They should really only be in `/var` if it is possible to change them in the UI (and therefore are not in Git). 
As soon as they are getting deployed by a pipeline, you should put them into the `/config/pimcore/classes` directory after creating/modifying them. 
At that point they should also be handled as a code - in Git and maintained there.
This ensures a clear separation for immutable deployments and volumes and also avoids confusion for developers.
In case that you need your classes writable in `/config/pimcore/classes` e.g. to continue to edit them using the UI, you can use `PIMCORE_CLASS_DEFINITION_WRITABLE` env variable in your local dev environment. Note: This won't work in PaaS environments, as the `/config/pimcore/classes` is considered there as code and therefore on an immutable filesystem. If you need to have them still editable in the UI in PaaS environments, consider to continue to use the `/var` directory - see explanation above. 

Following docs are explaining in details [Pimcore class definitions](https://pimcore.com/docs/platform/Pimcore/Deployment/Deployment_Tools#pimcore-class-definitions) 
and [environment specific configurations](https://pimcore.com/docs/platform/Pimcore/Deployment/Configuration_Environments/#environment-specific-configurations).

As with Pimcore configurations also Pimcore class definitions are saved as PHP configuration files and therefore can be added to version control systems and be deployed to different deployment stages.
The PHP configuration files and PHP classes will be written to the `var/classes` directory by default.
To disallow modification and turn a class to be read-only, you can create a copy at `config/pimcore/classes` (mind the `PIMCORE_CLASS_DEFINITION_WRITABLE` variable).
It all depends on your project specific needs.

## Keeping your PaaS bundle up-to-date

After updating your PaaS bundle to a newer version you also need to update the files that PaaS bundle provides.
Command `./vendor/bin/pimcore-paas-install-config` accepts flag `--force-overwrite` or `-f`.
Use this flag with caution, as it will replace your existing files with the new versions from the PaaS bundle.
Merging your exiting changes to the latest changes from PaaS bundle is a manual process.
