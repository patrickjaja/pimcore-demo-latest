# FAQ

## Nginx/Router
**Q: What exactly is the function of Nginx within the application (reverse proxy, load balancer, etc.)? Or does load balancing happen one level higher within the VPN of the Platform.sh region (keyword Availability Zones)?**  
Nginx is used as a web server and the reverse proxy for PHP/FPM, so the actual Pimcore application.  
There is no loadbalancing in case of a Grid project, as there is only 1 instance running at the same time for each containers.  

## Services
**Q: What are the scaling options for the individual services ie MariaDB, within a Pimcore application? Which services can actually be scaled (e.g. multiple containers)? What exactly happens there?**  
Currently on Pimcore PaaS there is no option to have multiple instance of the same app container  - horizontal scaling.  
We can only give provide more resources via T-shirt sizing or with [flexible resources](https://docs.platform.sh/create-apps/flexible-resources.html) - vertical scaling.  
Take note that you need to respect your plan sizing and properly size all resources.  

However, the underlying infrastructure is able to provide both vertical or horizontal scaling, this is exposed in Upsun, but not yet in Pimcore PaaS. 
We are also working on [autoscaling support](https://next.platform.sh/c/339-autoscaling). It should arrive at some point on Pimcore PaaS but so far we don't have any ETA.

## PHP worker
**Q: What are the PHP workers underneath the services for or what is their function?**  
Worker instances are well explained here https://docs.platform.sh/create-apps/workers.html#workers-vs-cron-jobs
In our use case, workers are handling message transports - `message:consume` commands.

## Mercure
**Q: Is Mercure always installed/activated in a Pimcore PaaS application or only when Pimcore Direct Edit is used?**  
Mercure is available as a stand-alone app within the `applications.yaml` and can be use as needed.
By default its commented out.

## Redis 
**Q: Is there a reason that the sessions are stored in PDO instead of in Redis?**  
We have chosen the PDO as default session storage on PaaS because our Redis service is configured for the caching purpose with the following config:  
```bash
configuration:
    maxmemory_policy: volatile-lru
``` 
This has a risk of Redis kicking the active session, and hence the reason for using PDO as session storage. 