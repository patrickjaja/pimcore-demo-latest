# Customize Infrastructure Configuration

The template configuration files, which were installed by the previous step, need to be customized for your project.
Please go through at least the files in the `.platform/` folder and adapt it to your needs.

## Configure your environments

The default Symfony environment for Pimcore projects is `dev`, you may customize that for your PaaS environments accordingly.

1. In Console, go to `Settings` -> `Environments` and select an environment, e.g. `production`.
2. Open the tab `Variables`
3. Create a new variable with the name `env:APP_ENV` and the value `prod`
4. Pimcore now runs in production mode

## RabbitMQ

RabbitMQ is configured as the default transport for Symfony messenger.
If you would like to change that, you need to change following files and remove RabbitMQ config and dependencies:

`config\pimcore\startup.php`, `config\packages\messenger.yaml`, `.platform\applications.yaml`, `.platform\services.yaml`, `composer.json`

## OpenSearch 

For staring an new project based on Enterprise demo, default configuration on the Pimcore side is done for OpenSearch.
In the case you are migrating your project and want to use Opensearch you should enable this configuration

```bash
pimcore_open_search_client:
    clients:
        default:
            hosts: ['%env(PIMCORE_OPENSEARCH_CLIENT_HOST)%']
            ssl_verification: false
```

## S3 buckets storage

We support S3 buckets as storage. Default configuration is provided by Pimcore.
If you would like to S3 buckets as a storage, you would need to edit flysystem storage S3 config in the `template/config/platform.yaml` and you would need to add following variables to your project/environment in console:

-   `env:S3_STORAGE_KEY` - with the access key
-   `env:S3_STORAGE_SECRET`- with the secret
-   `env:S3_PRIVATE_BUCKET` - with the name of the bucket which will contain private files
-   `env:S3_PUBLIC_BUCKET` - with the name of the bucket which will contain publicly available files

## S3 bucket policies 

Your bucket policies could be configured as following:

- **Public** files

```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::id:user/username"
            },
            "Action": [
                "s3:ListBucket",
                "s3:GetObject",
                "s3:PutObject",
                "s3:ReplicateObject",
                "s3:DeleteObject"
            ],
            "Resource": [
                "arn:aws:s3:::pimcore-public/*",
                "arn:aws:s3:::pimcore-public"
            ]
        },
        {
            "Sid": "PublicRead",
            "Effect": "Allow",
            "Principal": "*",
            "Action": "s3:GetObject",
            "Resource": "arn:aws:s3:::pimcore-public/*"
        }
    ]
}
```

- **Private** files

```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::id:user/username"
            },
            "Action": [
                "s3:ListBucket",
                "s3:GetObject",
                "s3:PutObject",
                "s3:ReplicateObject",
                "s3:DeleteObject"
            ],
            "Resource": [
                "arn:aws:s3:::pimcore-private/*",
                "arn:aws:s3:::pimcore-private"
            ]
        }
    ]
}
```

You could also combine Cloudfront with your S3 config to optimize performance and costs of an S3 bucket. [Check the guide](https://pimcore.com/docs/platform/Pimcore/Installation_and_Upgrade/System_Setup_and_Hosting/File_Storage_Setup/)


## Sitemaps configuration

By default sitemaps configs are commented out. 
If you would like to enable it, uncomment it within `applications.yaml` under `mounts` and `web` configuration.

## Workflow Designer

There is a limitation with workflows due to the functionality of the Symfony Workflow component.
The component only supports Symfony Config, which prevents setting the configuration via LocationAwareConfigRepository. 
For more information, see the [Pimcore documentation on configuration storage locations](https://docs.pimcore.com/platform/Pimcore/Deployment/Configuration_Environments/#configuration-storage-locations--fallbacks)

We recommend to create workflows using the Workflow Designer locally and put the generated workflow configuration file(s) into the ie. `'%kernel.project_dir%/config/workflows/workflows.yaml'` and add them to Git.
To do so the following change in the configuration is necessary: 
Add an import statement in the `/config/config.yaml` file:
```text
imports:
    - { resource: 'workflows/' }
```
Ensure that your workflow YAML file(s) is placed in the `/config/workflows/` directory.
By following these steps, the workflow configuration process should work smoothly.
