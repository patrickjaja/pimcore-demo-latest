/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

document.addEventListener(pimcore.events.pimcoreReady, (e) => {
    window.setTimeout(checkLicense.bind(this), 5000);
});

function checkLicense() {

    Ext.Ajax.request({
        url: "/admin/enterprise-subscription-tools/instance-info",
        method: "get",
        success: function (response) {
            const rdata = Ext.decode(response.responseText);
            let request = new XMLHttpRequest();

            request.open('POST', "https://license.pimcore.com/pimcore-license/check", true);

            let data = new FormData();
            data.append('instanceId', rdata.instanceId);
            data.append('instanceCode', rdata.instanceCode);
            data.append('environment', rdata.environment);
            data.append('main_domain', pimcore.settings.main_domain);
            data.append('current_domain', window.location.hostname);

            request.addEventListener('loadend', function(request, event) {
                if (request.status >= 200 && request.status < 300) {
                    const response = Ext.decode(request.responseText);


                    const notificationMenu = pimcore.globalmanager.get('layout_toolbar').notificationMenu;
                    let cssClass = '';
                    if(notificationMenu) {
                        cssClass = 'with-notifications';
                    }

                    let tooltipText = 'bundle_enterprise_subscription_status_valid';
                    if(!response.licenseValid) {
                        tooltipText = 'bundle_enterprise_subscription_status_error';
                    } else if(response.isDeveloperPackage) {
                        tooltipText = 'bundle_enterprise_subscription_status_dev_package';
                    } else if(response.notProductionSystem) {
                        tooltipText = 'bundle_enterprise_subscription_status_dev_system';
                    }

                    const navEl = Ext.get('pimcore_status').insertSibling('' +
                        '<div id="pimcore_enterprise_subscription" data-menu-tooltip="' + t(tooltipText) + '" class="pimcore_icon_comments ' + cssClass + '"><div class="icon" />'
                        , 'after');
                    pimcore.layout.toolbar.prototype.licenseChecker = this.menu;

                    Ext.get('pimcore_sidebar').addCls(cssClass);
                    Ext.get('pimcore_loading').addCls(cssClass);

                    const domElement = Ext.dom.Query.select('.x-body .sf-minitoolbar');
                    const sfToolbar = Ext.get(domElement[0]);
                    if(sfToolbar) {
                        sfToolbar.addCls(cssClass);
                    }

                    navEl.show();
                    if(response.licenseValid) {
                        navEl.addCls('green');
                    }
                    if(response.isDeveloperPackage || response.notProductionSystem) {
                        navEl.addCls('developer');
                    }

                    navEl.on("mousedown", function() {
                        window.open("https://license.pimcore.com/pimcore-license/info?instanceCode=" + rdata.instanceCode);
                    });
                    pimcore.helpers.initMenuTooltips();

                } else {
                    console.warn(request.statusText, request.responseText);
                }

            }.bind(this, request));

            request.send(data);

        }.bind(this)
    });
}