<?php

/**
 * Pimcore
 *
 * This source file is available under following license:
 * - Pimcore Commercial License (PCL)
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     PCL
 */

namespace Pimcore\Bundle\EnterpriseSubscriptionToolsBundle;

use Pimcore\Bundle\EnterpriseSubscriptionToolsBundle\DependencyInjection\Compiler\ContentSecurityPolicyUrlsPass;
use Pimcore\Extension\Bundle\AbstractPimcoreBundle;
use Pimcore\Extension\Bundle\PimcoreBundleAdminClassicInterface;
use Pimcore\Extension\Bundle\Traits\BundleAdminClassicTrait;
use Pimcore\Extension\Bundle\Traits\PackageVersionTrait;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class PimcoreEnterpriseSubscriptionToolsBundle extends AbstractPimcoreBundle implements PimcoreBundleAdminClassicInterface
{
    use BundleAdminClassicTrait;
    use PackageVersionTrait;

    public function getJsPaths(): array
    {
        return [
            '/bundles/pimcoreenterprisesubscriptiontools/js/pimcore/startup.js'
        ];
    }

    public function getCssPaths(): array
    {
        return [
            '/bundles/pimcoreenterprisesubscriptiontools/css/pimcore/admin.css'
        ];
    }

    /**
     * Returns the composer package name used to resolve the version
     *
     * @return string
     */
    protected function getComposerPackageName(): string
    {
        return 'pimcore/enterprise-subscription-tools';
    }

    public function build(ContainerBuilder $container)
    {
        $container->addCompilerPass(new ContentSecurityPolicyUrlsPass());
    }
}
