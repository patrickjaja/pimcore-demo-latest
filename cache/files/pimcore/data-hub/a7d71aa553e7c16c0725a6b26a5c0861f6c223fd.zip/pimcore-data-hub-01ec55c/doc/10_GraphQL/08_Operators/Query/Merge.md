# Merge (deprecated)

This operator is deprecated and will be removed in the next major release.
